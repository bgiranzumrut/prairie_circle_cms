import React from "react";
import UserList from "./UserList";
import HomePage from "./HomePage";
function UsersPage() {
  return (
    <div>
      <UserList />
    </div>
  );
}

export default UsersPage;
